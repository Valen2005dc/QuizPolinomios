
package sumpoli;

import java.util.ArrayList;


public class Polinomio {
    
    
    public static ArrayList<Integer> sumaPolinomios(ArrayList<Integer> lista1, ArrayList<Integer> lista2)
    {
        
    int polinomio1 = lista1.size();
    int polinomio2 = lista2.size();
    
    
    int tamaño = Math.max(polinomio1, polinomio2);
    
    
    int[] arreglo1 = new int[tamaño];
    int[] arreglo2 = new int[tamaño];
    int[] resultadosuma = new int[tamaño];
    
   
    for (int i = 0; i < polinomio1; i++) 
    {
        arreglo1[tamaño - polinomio1 + i] = lista1.get(i);
    }
    
    
    for (int i = 0; i < polinomio2; i++) 
    {
        arreglo2[tamaño - polinomio2 + i] = lista2.get(i);
    }
    
    
    for (int i = 0; i < tamaño; i++)
    {
        resultadosuma[i] = arreglo1[i] + arreglo2[i];
    }
    
    
    int i = 0;
    while (i < tamaño && resultadosuma[i] == 0) 
    {
        i++;
    }
    
    ArrayList<Integer> resultado = new ArrayList<Integer>();
    for (int j = i; j < tamaño; j++) 
    {
        resultado.add(resultadosuma[j]);
    }
    
 
    return resultado;
    }
    
}
