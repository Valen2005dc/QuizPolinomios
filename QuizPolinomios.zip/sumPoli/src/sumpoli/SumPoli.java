
package sumpoli;

//Nicolas buritica y Valentina Daza

import java.util.ArrayList;
import static sumpoli.Polinomio.sumaPolinomios;


public class SumPoli {

    
    public static void main(String[] args) {
        
    ArrayList<Integer> lista1 = new ArrayList<Integer>();
    
    lista1.add(6);
    lista1.add(2);
    lista1.add(1);
    lista1.add(1);
    lista1.add(1);
    

    ArrayList<Integer> lista2 = new ArrayList<Integer>();
    
    lista2.add(9);
    lista2.add(1);
    lista2.add(0);
    lista2.add(0);
    
    System.out.println(lista1);
    System.out.println("+");
    System.out.println(lista2);  
    System.out.println("=");
    System.out.println("");
    System.out.println("Este es el resultado de la suma de polinomios : " + sumaPolinomios(lista1, lista2)); 
        
        
    
        
        
    }
    
}
